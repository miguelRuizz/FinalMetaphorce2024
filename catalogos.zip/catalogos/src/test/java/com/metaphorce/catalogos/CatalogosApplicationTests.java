package com.metaphorce.catalogos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogosApplicationTests {

	@Test
	void contextLoads() {
	}

}
