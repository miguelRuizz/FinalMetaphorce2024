package com.metaphorce.bitacora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitacoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
