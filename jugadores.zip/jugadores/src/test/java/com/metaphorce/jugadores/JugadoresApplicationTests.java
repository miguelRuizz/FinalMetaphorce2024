package com.metaphorce.jugadores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JugadoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
